package pack.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	// SecurityFilterChain을 빈으로 생성
	// Spring Security는 Security와 관련된 다양한 기능을 FilterChain으로 제공함
	// 클라이언트요청 -> 필터 -> 필터 -> ... -> DispatcherServlet을 만난다.(Controller를 수행)
	@Bean
	SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception{
		String[] whiteList = {
				"/", "/notice", "/shop", "/user/loginform", "/user/login_fail", "/user/expired", "/user/requiredloginform"
		};
		
		httpSecurity.csrf(csrf -> csrf.disable())	// XSS 공격 방지용 csrf 처리 안함
					.authorizeHttpRequests(config ->	// 사용자 인증과 권한을 설정 
						config.requestMatchers("/error", "/.well-known/**", "/favicon.ico").permitAll()	// 모든 사용자들에게 허용된 url
							  .requestMatchers(whiteList).permitAll()	// 모든 사용자들에게 허용된 url
							  .requestMatchers("/admin/**").hasRole("ADMIN")	// ADMIN 권한에게 허용된 url
							  .requestMatchers("/staff/**").hasAnyRole("STAFF", "ADMIN")	// ADMIN 또는 STAFF 권한에게 허용된 url
							  .anyRequest().authenticated()		// 위의 요청을 제외한 나머지 모든 요청은 인증 필요 
					)
					.formLogin(config -> 
						config.loginPage("/user/requiredloginform")
							  .loginProcessingUrl("/user/login")
							  .usernameParameter("userName")
							  .passwordParameter("password")
							  .successHandler(new AuthSuccessHandler())
							  .failureForwardUrl("/user/login_fail")
							  .permitAll()
					)
					.logout(config -> 
						config.logoutUrl("/user/logout")
							  .logoutSuccessUrl("/")
							  .permitAll()
					)
					.exceptionHandling(config ->		// 인증 처리 중 예외가 발생했을 때 
						config.accessDeniedPage("/user/denied")
					)
					.sessionManagement(config ->	// 세션 관리 
						config.maximumSessions(1)	// 최대 허용 세션 갯수
							  .expiredUrl("/user/expired")	// 허용 세현 갯수 초과로 로그인 헤제된 경우 이동 경로
					);
					
		
		return httpSecurity.build();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public AuthenticationManager authenticationManager(HttpSecurity httpSecurity, UserDetailsService userDetailsService,
			BCryptPasswordEncoder bCryptPasswordEncoder) throws Exception {
		AuthenticationManagerBuilder managerBuilder = httpSecurity.getSharedObject(AuthenticationManagerBuilder.class);
		managerBuilder.userDetailsService(userDetailsService)
					  .passwordEncoder(bCryptPasswordEncoder);
		
		return managerBuilder.build();
	}
	
}
