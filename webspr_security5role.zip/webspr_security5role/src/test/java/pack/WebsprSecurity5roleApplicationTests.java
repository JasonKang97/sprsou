package pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsprSecurity5roleApplicationTests {

	@Test
	void contextLoads() {
	}

}
